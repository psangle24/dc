import java.rmi.*;
import java.util.Scanner;
import java.util.InputMismatchException;

public class Client
{
	public static void main(String args[]) throws Exception
	{
		double val,con;char ans=0;int cho=0;
		String opt=null;
		Scanner sc = new Scanner(System.in);
	        //System.setProperty("java.security.policy","file:///tmp/test.policy");
		Add c_convert = (Add)Naming.lookup("rmi://192.168.0.105:1099/CON");
		do
		{
			try
			{
				System.out.println("\n\nCurrency Conversion options available :");
				System.out.print("1.USD (64.22)\t2.SAR (17.13)\t3.GBP (88.82)\t4.SGD (48.37)\t5.AUD (50.17)\t6.Quit\n\nEnter your choice : ");
				cho=Integer.parseInt(sc.nextLine());

				if(cho==6)
				{
					System.out.println("Program terminated!");
					System.exit(0);
				}
			
				if(cho!=1 && cho!=2 && cho!=3 && cho!=4 && cho!=5)
					System.out.println("Invalid choice!");
				else
				{
					System.out.print("Enter amount : ");
					val=Double.parseDouble(sc.nextLine());
					con = c_convert.convert(val,cho);
					if(cho==1)opt="USD";
					if(cho==2)opt="SAR";
					if(cho==3)opt="GBP";
					if(cho==4)opt="SGD";
					if(cho==5)opt="AUD";
					System.out.println("" + val + " " + opt + " in Rupees are " + Math.round(con*100.0)/100.0);
				}
			}
			catch(InputMismatchException e)
			{
				System.out.println("Invalid input!");
			}
			catch(NumberFormatException e)
			{
				System.out.println("Invalid input!");
			}
			finally
			{
				System.out.print("\nDo you want to enter again?(Y/N) :");
				ans=sc.next(".").charAt(0);
				sc.nextLine();
			}
		}while(ans=='Y' || ans=='y');
	}
}
