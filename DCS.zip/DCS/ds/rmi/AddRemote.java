import java.rmi.*;
import java.rmi.server.*;

public class AddRemote extends UnicastRemoteObject implements Add
{
	public AddRemote() throws RemoteException
	{
		super();
	}
	
	public double convert(double a,int b) throws RemoteException
	{
		double inr=0;
		switch(b)
		{
			case 1:
				inr=a*64.22;break;
			case 2:
				inr=a*17.13;break;
			case 3:
				inr=a*88.82;break;
			case 4:
				inr=a*48.37;break;
			case 5:
				inr=a*50.17;break;
		}
		return inr;
	}
}
