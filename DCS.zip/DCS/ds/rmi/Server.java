import java.rmi.*;

public class Server
{
	public static void main(String args[]) throws Exception
	{
		//System.setProperty("java.rmi.server.hostname", "192.168.0.105");
		//System.setProperty("java.security.policy", "file:///tmp/test.policy");
		
		AddRemote s_convert = new AddRemote();
		Naming.rebind("rmi://192.168.0.105:1099/CON",s_convert);
		System.out.println("Server ready ..........");
	}
}
