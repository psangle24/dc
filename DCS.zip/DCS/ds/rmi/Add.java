import java.rmi.*;

public interface Add extends Remote
{
	public abstract double convert(double a,int b) throws RemoteException;
}
