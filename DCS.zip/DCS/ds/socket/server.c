#include<stdio.h>
#include<ctype.h>
#include<string.h>
#include<stdlib.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<unistd.h>
#include<pthread.h>

void *connection_handler(void *);

int main(int argc , char *argv[])
{

	int socket_desc , client_sock , c , *new_sock;
	struct sockaddr_in server , client;

	socket_desc = socket(AF_INET , SOCK_STREAM , 0);
	if (socket_desc == -1)
	{
		printf("Could not create socket");
	}
	puts("Socket created");

	server.sin_family = AF_INET;
	server.sin_addr.s_addr = INADDR_ANY;
	server.sin_port = htons( 3000 );

	if( bind(socket_desc,(struct sockaddr *)&server , sizeof(server)) <0)
	{
		perror("bind failed. Error");
		return 1;
	}
	puts("bind done");

	listen(socket_desc , 3);
	
	puts("Waiting for incoming connections...");
	c = sizeof(struct sockaddr_in);

	while(client_sock=accept(socket_desc,(struct sockaddr*)&client,(socklen_t*)&c))
	{
		puts("Connection accepted");
		pthread_t sniffer_thread;
		new_sock = malloc(1);
		*new_sock = client_sock;
		if(pthread_create(&sniffer_thread,NULL,connection_handler , (void*) new_sock) < 0)
		{
			perror("could not create thread");
			return 1;
		}
		puts("Handler assigned");
	}
	if (client_sock < 0)
	{
		perror("accept failed");
		return 1;
	}
	return 0;
}

void *connection_handler(void *socket_desc)
{

	int sock = *(int*)socket_desc;
	int n;
	char c_msg[2000];
	while((n=recv(sock,c_msg,2000,0))>0)
	{
		int end=strlen(c_msg)-1,i=0;
		int temp=end;

			char new_msg[2000],new_msg2[2000],new_msg3[2000],abcd[50];

			//reverse string
			while(i<end)
			{
				new_msg[i]=c_msg[end-1];
				new_msg[end-1]=c_msg[i];
				i++;end--;
			}
			new_msg[temp]='\n';
			new_msg[temp+1]='\0';

			send(sock,new_msg,n,0);
			bzero(new_msg,2001);

			//to upper case
			i=0;
			while(i<temp)
			{
				new_msg2[i]=toupper(c_msg[i]);
				i++;
			}
			new_msg2[temp]='\n';
			new_msg2[temp+1]='\0';
			send(sock,new_msg2,n,0);
			bzero(new_msg2,2001);


			//to lower case
			i=0;
			while(i<temp)
			{
				new_msg3[i]=tolower(c_msg[i]);
				i++;
			}
			new_msg3[temp]='\n';
			new_msg3[temp+1]='\0';
			send(sock,new_msg3,n,0);
			bzero(new_msg3,2001);

			if(temp>0)
			{
				sprintf(abcd,"%d\n",temp);
				send(sock,abcd,n,0);
				bzero(abcd,51);
			}

		bzero(c_msg,2001);
	
	}
	close(sock);
	if(n==0)
	{
		puts("Client Disconnected");
	}
	else
	{
		perror("recv failed");
	}
	return 0;
}
